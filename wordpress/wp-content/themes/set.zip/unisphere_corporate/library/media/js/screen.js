/**
 * Javascript - jQuery enabled
 * 
 * @package WPFramework
 * @subpackage Media
 */
 
jQuery(document).ready(function(){

	/* Font Replacement */
	Cufon.replace('h1'); 
	Cufon.replace('h2', { hover: true });
	Cufon.replace('h3');
	Cufon.replace('h4');
	Cufon.replace('h5');
	Cufon.replace('h6');
 
});
